import wrapper as ts
import glob
import array as ar
import numpy as np

icount=0
n=3127.0
kappa=20
w=1.0
E=2.0
F=2.0
f=open('t_vs_ad_area_Wad_W_b_Wd_Wa_E_2_F_2_c_75_cylinder.dat','a')
for file in glob.glob("../timestep_000[0-9][0-9][0-9].vtu"):
    vesicle=ts.parseDump(file)
    ts.vesicle_area(vesicle)
    total_area=vesicle.contents.area
    name=int(file[13:18]) 
    z_ad=-15.771934
    r=10.0
    z_c=z_ad - r

    cmx=0.0000
    cmy=0.0000
    cmz=0.0000
    for i in range(vesicle.contents.vlist.contents.n):
        x=vesicle.contents.vlist.contents.vtx[i].contents.x
        y=vesicle.contents.vlist.contents.vtx[i].contents.y
        z=vesicle.contents.vlist.contents.vtx[i].contents.z
        cmx+=x
        cmy+=y
        cmz+=z
    cmx/=vesicle.contents.vlist.contents.n
    cmy/=vesicle.contents.vlist.contents.n
    cmz/=vesicle.contents.vlist.contents.n

    Ad=0.000000000
    Wb=0.0000000000
    Wd=0.0000000000
    Wa=0.0000000000
    for i in range(vesicle.contents.vlist.contents.n): 
        Wb+=vesicle.contents.vlist.contents.vtx[i].contents.energy

        if (vesicle.contents.vlist.contents.vtx[i].contents.c > 0.00000000000001):
            for j in range (vesicle.contents.vlist.contents.vtx[i].contents.neigh_no):
                if (vesicle.contents.vlist.contents.vtx[i].contents.neigh[j].contents.c > 0.00000000000001):
                    Wd+=-0.5

            xnorm=0.00000000000
            ynorm=0.00000000000
            znorm=0.00000000000
            for j in range (vesicle.contents.vlist.contents.vtx[i].contents.tristar_no):
                xnorm+=vesicle.contents.vlist.contents.vtx[i].contents.tristar[j].contents.xnorm
                ynorm+=vesicle.contents.vlist.contents.vtx[i].contents.tristar[j].contents.ynorm
                znorm+=vesicle.contents.vlist.contents.vtx[i].contents.tristar[j].contents.znorm
            normal=(xnorm**2 + ynorm**2 + znorm**2)**0.5
            xnorm/=normal
            ynorm/=normal
            znorm/=normal
            x=vesicle.contents.vlist.contents.vtx[i].contents.x - cmx
            y=vesicle.contents.vlist.contents.vtx[i].contents.y - cmy
            z=vesicle.contents.vlist.contents.vtx[i].contents.z - cmz
            Wa+=F*(xnorm*x + ynorm*y + znorm*z)

        x=vesicle.contents.vlist.contents.vtx[i].contents.x
        y=vesicle.contents.vlist.contents.vtx[i].contents.y
        z=vesicle.contents.vlist.contents.vtx[i].contents.z
        dist=((y**2) + (z-z_c)**2)**0.5
        if(dist<(r+1)):
            Ad+=1.0
    area=(Ad/n)*total_area
    f.write('{}, {}, {}, {}, {}, {}, {} \n'.format(name,Ad,area,(-Ad*E),(kappa*Wb),Wd*w, Wa))


                        
