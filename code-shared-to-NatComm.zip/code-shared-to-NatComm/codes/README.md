TRISURF NG
==========


1. Instalation
--------------

To compile the program, user must have ``automake``, and ``gcc`` tools installed on the computer.

Required C libraries are:
* libconfuse
* libgsl
* libxml2
* zlib

and python libraries for running tsmgr:
* tabulate
* psutil
* configobj

On Debian based systems, install prerequisities by typing the following command in the command line:

``sudo apt-get install libconfuse-dev libgsl0-dev libxml2-dev zlib1g-dev automake gcc python3-psutil python3 python3-pip``
``sudo pip3 install tabulate configobj``

Move to the project root directory and compile with:

``./configure``

``make``

``make install``

If you are experiencing difficulties due to different automake versions, proceed with the longer procedure:

``aclocal``

``autoheader``

``automake -ac``

``autoconf``

``autoreconf -if``

``libtoolize --force``

``automake -ac``

``./configure``

Then, go inside the "src" directory, and run

``make``

``sudo make install``

``sudo ldconfig``


This procedure can be done automatically by calling the build.sh script.

2. Use
------

Prepare tape file, storing the definition for the simulation. You can use the sample tape file in the ``src/`` directory as a template for your simulation.

Run simulations with ``trisurf --force-from-tape`` for initial run, or ``trisurf`` for continuing aborted simulations, or ``trisurf  --restore-from-vtk timestep_XXXXXX.vtu`` for continuing simulation starting from the initial condition that is in the configuration file "timestep_XXXXXX.vtu" etc. Few examples are provided in "example-tape-files". Please go to any of the example folder and run the command. The different elements of a tape file is described in the user manual "trisurf_algorithm.pdf".

======== LIBRARY VERSION ================

THis line seemed to fixed everything:
libtoolize --force


======= STATICALLY LINKING ==============
./configure --enable-static LDFLAGS=-static


========data visulatization==========
We use "paraview" software for visualization, and python for data analysis


======system requirments and simulation time=============
The current code is compiled and simulated in a linux desktop with version "ubuntu 18.04"

The compilation time is around 5 minutes.

The example run time is few minutes, but for actual simulation, it varies from few days to few weeks, depending upon the parameter regime and system size etc.

In our present work, the simulation time for a single run varies from 3 days to 2 weeks.


=========expected output from simulation=================
After a succesful run, one will expect output files with filename "timespet_XXXXXX.vtu", along with few other files such as dump.bin, stat file etc.


=========data analysis using python==============
After a successful run of a simulation, one can copy the python scripts to the folder where the timestap_XXXXXX.vtu files are located, and run the pythonscript by a command "python script_name.py". It will give some data files as a result. Please follow the documentation file provided for more informations about data structure and other stuffs.

